# -*- coding: utf-8 -*-
# 2. Добавить форматирование в сообщения в вашем мессенджере.
# 3. Реализовать возможность добавления фотографии в ваш профиль.
# 4. *Нужно сделать предыдущее задание и добавить смайлы в мессенджер.
# 5. *Нужно сделать предыдущее задание и применить разные эффекты к изображению в профиле.

import os.path
import sys

# import random
from PIL import Image, ImageDraw
from PIL.ImageQt import ImageQt
from PyQt5.QtGui import QPixmap, QIcon, QPalette
from PyQt5.QtWidgets import (QMainWindow, QLabel, QDesktopWidget, QSizePolicy, QScrollArea,
                             QAction, QFileDialog, QApplication)

from definitions import IMAGES_PATH

class Messenger_Window(QMainWindow):

    # noinspection PyArgumentList
    def __init__(self):
        super().__init__()
        self.currentImage = ''

        self.init_ui()

    def init_ui(self):
        self.setGeometry(300, 300, 350, 300)
        self.center()

        self.image_label = QLabel()
        self.image_label.setBackgroundRole(QPalette.Base)
        self.image_label.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Ignored)
        self.image_label.setScaledContents(True)

        self.scroll_area = QScrollArea()
        self.scroll_area.setBackgroundRole(QPalette.Dark)
        self.scroll_area.setWidget(self.image_label)
        self.setCentralWidget(self.scroll_area)
        self.create_actions()
        self.init_tool_bar()
        app_icon = QIcon(os.path.join(IMAGES_PATH, 'photos.png'))
        menubar = self.menuBar()
        file_menu = menubar.addMenu('File')
        file_menu.addAction(self.open_file)
        file_menu.addAction(self.save_file)
        self.enable_actions(False)
        self.setWindowTitle('Image processing')
        self.setWindowIcon(app_icon)
        self.statusBar().showMessage('Ready')

    # noinspection PyArgumentList
    def create_actions(self):
        send_icon = QIcon(os.path.join(IMAGES_PATH, 'paper-plane-1.png'))
        save_icon = QIcon(os.path.join(IMAGES_PATH, 'save.png'))
        gray_icon = QIcon(os.path.join(IMAGES_PATH, 'picture-gray.png'))
        sepia_icon = QIcon(os.path.join(IMAGES_PATH, 'picture-sepia.png'))
        bw_icon = QIcon(os.path.join(IMAGES_PATH, 'picture_bw.png'))
        bw_icon_2 = QIcon(os.path.join(IMAGES_PATH, 'picture_bw_2.png'))
        inv_icon = QIcon(os.path.join(IMAGES_PATH, 'picture_inv.png'))
        orig_icon = QIcon(os.path.join(IMAGES_PATH, 'picture.png'))
        self.open_file = QAction(open_icon, '&Open...', self, shortcut='Ctrl+O', triggered=self.dialog_open, )
        self.save_file = QAction(save_icon, '&Save as...', self, shortcut='Ctrl+S', triggered=self.dialog_save)
        self.set_gray_action = QAction(gray_icon, '&Gray tones', self, shortcut='Ctrl+G', triggered=self.set_gray)
        self.set_bw_action = QAction(bw_icon, 'Black and &white', self, shortcut='Ctrl+W', triggered=self.set_bw)
        self.set_bw2_action = QAction(bw_icon_2, 'Black and white method 2', self, shortcut='Ctrl+B',
                                      triggered=self.set_bw2)
        self.set_sepia_action = QAction(sepia_icon, 'Se&pia', self, shortcut='Ctrl+P', triggered=self.set_sepia)
        self.set_inverted_action = QAction(inv_icon, '&Inverted', self, shortcut='Ctrl+I', triggered=self.set_inverted)
        self.set_original_action = QAction(orig_icon, 'Original', self, shortcut='Ctrl+O', triggered=self.set_original)