# def main():
#     str = input()
#     a = int(str.split(' ')[0])
#     b = int(str.split(' ')[1])
#     c = a + b
#     print(c)

def main():
    with open('output.txt', 'w') as outfile, open('input.txt', 'r', encoding='utf-8') as infile:
        str_input = infile.readline()
        a = int(str_input.split(' ')[0])
        b = int(str_input.split(' ')[1])
        c = a + b
        outfile.write(str(c))

if __name__ == '__main__':
    main()
